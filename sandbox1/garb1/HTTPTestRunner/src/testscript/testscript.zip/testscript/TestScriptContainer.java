package testscript;

public interface TestScriptContainer {
	TestScript getTestScript(int index);
}
